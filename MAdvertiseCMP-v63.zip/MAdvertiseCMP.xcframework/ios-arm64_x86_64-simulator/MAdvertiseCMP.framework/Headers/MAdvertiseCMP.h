//
//  MAdvertiseCMP.h
//  MAdvertiseCMP
//
//  Created by Hussein Dimessi on 11/16/20.
//

#import <UIKit/UIKit.h>

//! Project version number for MAdvertiseCMP.
FOUNDATION_EXPORT double MAdvertiseCMPVersionNumber;

//! Project version string for MAdvertiseCMP.
FOUNDATION_EXPORT const unsigned char MAdvertiseCMPVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MAdvertiseCMP/PublicHeader.h>


